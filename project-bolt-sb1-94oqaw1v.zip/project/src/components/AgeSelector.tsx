import React from 'react';
import { getAgeGroup } from '../utils/ageConfig';

interface AgeSelectorProps {
  onAgeSelect: (age: number) => void;
}

export default function AgeSelector({ onAgeSelect }: AgeSelectorProps) {
  const ageRanges = [
    { label: 'Criança (7-12)', min: 7, max: 12 },
    { label: 'Adolescente (13-17)', min: 13, max: 17 },
    { label: 'Adulto (18-50)', min: 18, max: 50 }
  ];

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 p-8">
      <div className="bg-white rounded-xl shadow-2xl p-8 max-w-md w-full">
        <h1 className="text-3xl font-bold text-center mb-8">Selecione sua Idade</h1>
        <div className="space-y-4">
          {ageRanges.map((range) => (
            <button
              key={range.label}
              onClick={() => {
                const age = Math.floor((range.min + range.max) / 2);
                onAgeSelect(age);
              }}
              className="w-full bg-gradient-to-r from-purple-500 to-indigo-500 text-white py-4 px-6 rounded-lg text-xl font-semibold hover:opacity-90 transition-all transform hover:scale-105"
            >
              {range.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}