import React, { useState, useEffect } from 'react';
import { Brain, Heart, Trophy, Zap, Timer, Star, Focus } from 'lucide-react';
import { Challenge, GameState, TimerState } from '../types';
import { generateChallenge } from '../utils/challengeGenerator';
import ProgressBar from './ProgressBar';

interface GameBoardProps {
  ageGroup: 'child' | 'teen' | 'adult';
}

export default function GameBoard({ ageGroup }: GameBoardProps) {
  const [gameState, setGameState] = useState<GameState>({
    score: 0,
    level: 1,
    currentStreak: 0,
    bestStreak: 0,
    lives: 3,
    focusPoints: 0,
    timeBonus: 0,
    ageGroup
  });

  const [challenge, setChallenge] = useState<Challenge>(generateChallenge(1, ageGroup));
  const [feedback, setFeedback] = useState<string>('');
  const [timer, setTimer] = useState<TimerState>({
    timeLeft: challenge.timeLimit || 15,
    isActive: true
  });
  const [showBreakPrompt, setShowBreakPrompt] = useState(false);
  const [consecutiveAnswers, setConsecutiveAnswers] = useState(0);

  useEffect(() => {
    if (consecutiveAnswers >= 10) {
      setShowBreakPrompt(true);
      setConsecutiveAnswers(0);
    }
  }, [consecutiveAnswers]);

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    
    if (timer.isActive && timer.timeLeft > 0) {
      interval = setInterval(() => {
        setTimer(prev => ({
          ...prev,
          timeLeft: prev.timeLeft - 1
        }));
      }, 1000);
    } else if (timer.timeLeft === 0) {
      handleTimeUp();
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [timer.timeLeft, timer.isActive]);

  const handleTimeUp = () => {
    setGameState(prev => ({
      ...prev,
      lives: prev.lives - 1
    }));
    setFeedback('Tempo esgotado! 😔');
    
    if (gameState.lives <= 1) {
      setFeedback('Fim de jogo! Tente novamente!');
      setTimeout(resetGame, 2000);
    } else {
      nextChallenge();
    }
  };

  const handleAnswer = (answer: string) => {
    setTimer(prev => ({ ...prev, isActive: false }));
    setConsecutiveAnswers(prev => prev + 1);

    if (answer === challenge.correctAnswer) {
      const timeBonus = Math.floor(timer.timeLeft * 2);
      const newScore = gameState.score + challenge.points + timeBonus;
      const newStreak = gameState.currentStreak + 1;
      const newLevel = Math.floor(newScore / 1000) + 1;
      const focusBonus = timer.timeLeft > 10 ? 5 : 0;
      
      setGameState(prev => ({
        ...prev,
        score: newScore,
        level: newLevel,
        currentStreak: newStreak,
        bestStreak: Math.max(newStreak, prev.bestStreak),
        focusPoints: prev.focusPoints + focusBonus,
        timeBonus: prev.timeBonus + timeBonus
      }));
      
      setFeedback(`Correto! 🎉 +${timeBonus} pontos de tempo!`);
      setTimeout(nextChallenge, 1500);
    } else {
      setGameState(prev => ({
        ...prev,
        lives: prev.lives - 1,
        currentStreak: 0
      }));
      setFeedback('Incorreto! 😔 Tente novamente!');
      
      if (gameState.lives <= 1) {
        setFeedback('Fim de jogo! Tente novamente!');
        setTimeout(resetGame, 2000);
      } else {
        setTimeout(nextChallenge, 1500);
      }
    }
  };

  const nextChallenge = () => {
    const newChallenge = generateChallenge(gameState.level, ageGroup);
    setChallenge(newChallenge);
    setFeedback('');
    setTimer({
      timeLeft: newChallenge.timeLimit || 15,
      isActive: true
    });
  };

  const resetGame = () => {
    setGameState({
      score: 0,
      level: 1,
      currentStreak: 0,
      bestStreak: gameState.bestStreak,
      lives: 3,
      focusPoints: 0,
      timeBonus: 0,
      ageGroup
    });
    setConsecutiveAnswers(0);
    nextChallenge();
  };

  const takeBreak = () => {
    setShowBreakPrompt(false);
    setTimer(prev => ({ ...prev, isActive: false }));
    setFeedback('Faça uma pausa de 1 minuto! Respire fundo e relaxe. 😌');
    setTimeout(() => {
      setFeedback('Pronto para continuar? 💪');
      setTimeout(() => {
        nextChallenge();
      }, 2000);
    }, 60000);
  };

  const skipBreak = () => {
    setShowBreakPrompt(false);
    nextChallenge();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-xl shadow-2xl p-8 mb-8">
          <div className="flex justify-between items-center mb-8">
            <div className="flex items-center space-x-2">
              <Brain className="w-6 h-6 text-purple-600" />
              <span className="text-2xl font-bold">Treino Cognitivo TDAH</span>
            </div>
            <div className="flex space-x-6">
              <div className="flex items-center">
                <Trophy className="w-5 h-5 text-yellow-500 mr-2" />
                <span className="font-semibold">{gameState.score}</span>
              </div>
              <div className="flex items-center">
                <Star className="w-5 h-5 text-blue-500 mr-2" />
                <span className="font-semibold">Bônus: {gameState.timeBonus}</span>
              </div>
              <div className="flex items-center">
                <Focus className="w-5 h-5 text-purple-500 mr-2" />
                <span className="font-semibold">{gameState.focusPoints}</span>
              </div>
              <div className="flex items-center">
                <Zap className="w-5 h-5 text-blue-500 mr-2" />
                <span className="font-semibold">Nível {gameState.level}</span>
              </div>
              <div className="flex items-center">
                <Heart className="w-5 h-5 text-red-500 mr-2" />
                <span className="font-semibold">{gameState.lives}</span>
              </div>
            </div>
          </div>

          <div className="mb-6">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center">
                <Timer className="w-5 h-5 text-orange-500 mr-2" />
                <span className="font-medium">Tempo restante</span>
              </div>
              <span className="font-bold">{timer.timeLeft}s</span>
            </div>
            <ProgressBar 
              progress={(timer.timeLeft / (challenge.timeLimit || 15)) * 100}
              colorClass={timer.timeLeft > 5 ? 'bg-green-500' : 'bg-red-500'}
            />
          </div>

          <div className="text-center mb-8">
            <div className="text-2xl font-medium mb-4">{challenge.question}</div>
            {feedback && (
              <div className={`text-lg font-bold mb-4 ${
                feedback.includes('Correto') ? 'text-green-500' : 
                feedback.includes('pausa') ? 'text-blue-500' : 'text-red-500'
              }`}>
                {feedback}
              </div>
            )}
          </div>

          {showBreakPrompt ? (
            <div className="text-center p-6 bg-blue-50 rounded-lg mb-6">
              <h3 className="text-xl font-bold mb-4">Que tal fazer uma pausa? 😊</h3>
              <p className="mb-4">Você está indo muito bem! Uma pequena pausa pode ajudar a manter o foco.</p>
              <div className="flex justify-center space-x-4">
                <button
                  onClick={takeBreak}
                  className="bg-blue-500 text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition-colors"
                >
                  Fazer pausa (1 min)
                </button>
                <button
                  onClick={skipBreak}
                  className="bg-gray-500 text-white px-6 py-3 rounded-lg hover:bg-gray-600 transition-colors"
                >
                  Continuar jogando
                </button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-4">
              {challenge.options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => handleAnswer(option)}
                  className="bg-gradient-to-r from-purple-500 to-indigo-500 text-white py-6 px-8 rounded-lg text-xl font-semibold hover:opacity-90 transition-all transform hover:scale-105"
                >
                  {option}
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-gray-600">Sequência atual</p>
              <p className="text-xl font-bold">{gameState.currentStreak} 🔥</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Melhor sequência</p>
              <p className="text-xl font-bold">{gameState.bestStreak} 🏆</p>
            </div>
            <button
              onClick={resetGame}
              className="bg-red-500 text-white px-6 py-3 rounded-lg hover:bg-red-600 transition-colors transform hover:scale-105"
            >
              Recomeçar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}