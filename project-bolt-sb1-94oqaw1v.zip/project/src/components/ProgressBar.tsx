interface ProgressBarProps {
  progress: number;
  colorClass: string;
}

export default function ProgressBar({ progress, colorClass }: ProgressBarProps) {
  return (
    <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
      <div 
        className={`h-full ${colorClass} transition-all duration-300 ease-out`}
        style={{ width: `${Math.max(0, Math.min(100, progress))}%` }}
      />
    </div>
  );
}