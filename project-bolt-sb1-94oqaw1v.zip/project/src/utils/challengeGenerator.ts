import { Challenge, AgeGroupConfig } from '../types';
import { ageGroupConfigs } from './ageConfig';

const generateSequenceChallenge = (difficulty: number, ageGroup: 'child' | 'teen' | 'adult'): Challenge => {
  const config = ageGroupConfigs[ageGroup];
  const length = Math.min(2 + Math.floor(difficulty / 2), 6);
  
  let sequence: number[];
  let nextNumber: number;
  let step: number;
  
  if (ageGroup === 'child') {
    // Simple counting or skip counting for children
    step = Math.floor(difficulty / 2) + 1;
    const start = Math.floor(Math.random() * 5) + 1;
    sequence = Array.from({ length }, (_, i) => start + (step * i));
    nextNumber = start + (step * length);
  } else {
    // More complex patterns for teens and adults
    const operations = [
      (n: number) => n + step,
      (n: number) => n * 2,
      (n: number) => n + (step * 2)
    ];
    step = Math.floor(Math.random() * 3) + 1;
    const operation = operations[Math.floor(Math.random() * (ageGroup === 'teen' ? 2 : 3))];
    
    sequence = [Math.floor(Math.random() * 5) + 1];
    for (let i = 1; i < length; i++) {
      sequence.push(operation(sequence[i - 1]));
    }
    nextNumber = operation(sequence[sequence.length - 1]);
  }
  
  const options = [
    nextNumber.toString(),
    (nextNumber + step).toString(),
    (nextNumber - step).toString(),
    (nextNumber + step * 2).toString(),
  ].sort(() => Math.random() - 0.5);

  return {
    id: Date.now(),
    type: 'sequence',
    difficulty,
    ageGroup,
    question: `Qual é o próximo número na sequência?\n${sequence.join(', ')}, ...`,
    options,
    correctAnswer: nextNumber.toString(),
    points: Math.floor(difficulty * 10 * config.pointsMultiplier),
    timeLimit: Math.floor((20 - Math.min(10, difficulty)) * config.timeMultiplier)
  };
};

const generatePatternChallenge = (difficulty: number, ageGroup: 'child' | 'teen' | 'adult'): Challenge => {
  const config = ageGroupConfigs[ageGroup];
  
  const patterns = {
    child: [
      { sequence: ['🐶', '🐱', '🐶'], next: '🐱' },
      { sequence: ['🌞', '🌙', '🌞'], next: '🌙' },
      { sequence: ['🍎', '🍌', '🍎'], next: '🍌' }
    ],
    teen: [
      { sequence: ['🔴', '🔵', '🟡', '🔴'], next: '🔵' },
      { sequence: ['🎨', '🎭', '🎪', '🎨'], next: '🎭' },
      { sequence: ['1️⃣', '2️⃣', '3️⃣', '1️⃣'], next: '2️⃣' }
    ],
    adult: [
      { sequence: ['🔺', '🔻', '⭐', '🔺', '🔻'], next: '⭐' },
      { sequence: ['A1', 'B2', 'C3', 'A1'], next: 'B2' },
      { sequence: ['⬡', '⬢', '⬡', '⬢'], next: '⬡' }
    ]
  };
  
  const agePatterns = patterns[ageGroup];
  const pattern = agePatterns[Math.floor(Math.random() * agePatterns.length)];
  const options = [...new Set([...pattern.sequence, pattern.next])].sort(() => Math.random() - 0.5);

  return {
    id: Date.now(),
    type: 'pattern',
    difficulty,
    ageGroup,
    question: `Qual símbolo completa o padrão?\n${pattern.sequence.join(' ')} ...`,
    options,
    correctAnswer: pattern.next,
    points: Math.floor(difficulty * 15 * config.pointsMultiplier),
    timeLimit: Math.floor((15 - Math.min(7, difficulty)) * config.timeMultiplier)
  };
};

const generateMemoryChallenge = (difficulty: number, ageGroup: 'child' | 'teen' | 'adult'): Challenge => {
  const config = ageGroupConfigs[ageGroup];
  let numbers: number[];
  
  if (ageGroup === 'child') {
    numbers = Array.from(
      { length: Math.min(difficulty + 1, 3) },
      () => Math.floor(Math.random() * 5) + 1
    );
  } else if (ageGroup === 'teen') {
    numbers = Array.from(
      { length: Math.min(difficulty + 2, 4) },
      () => Math.floor(Math.random() * 9) + 1
    );
  } else {
    numbers = Array.from(
      { length: Math.min(difficulty + 2, 5) },
      () => Math.floor(Math.random() * 12) + 1
    );
  }
  
  const sum = numbers.reduce((a, b) => a + b, 0);
  const options = [
    sum.toString(),
    (sum + 1).toString(),
    (sum - 1).toString(),
    (sum + 2).toString(),
  ].sort(() => Math.random() - 0.5);

  return {
    id: Date.now(),
    type: 'memory',
    difficulty,
    ageGroup,
    question: `Qual é a soma dos números?\n${numbers.join(' + ')} = ?`,
    options,
    correctAnswer: sum.toString(),
    points: Math.floor(difficulty * 20 * config.pointsMultiplier),
    timeLimit: Math.floor((25 - Math.min(15, difficulty)) * config.timeMultiplier)
  };
};

const generateFocusChallenge = (difficulty: number, ageGroup: 'child' | 'teen' | 'adult'): Challenge => {
  const config = ageGroupConfigs[ageGroup];
  
  const symbolSets = {
    child: ['🐶', '🐱', '🐰', '🐼'],
    teen: ['🎨', '🎭', '🎪', '🎯', '🎲'],
    adult: ['🔴', '🔵', '🟡', '🟢', '🟣', '⚪']
  };
  
  const symbols = symbolSets[ageGroup];
  const targetSymbol = symbols[Math.floor(Math.random() * symbols.length)];
  const count = Math.min(difficulty + (ageGroup === 'child' ? 2 : 3), 
    ageGroup === 'child' ? 6 : ageGroup === 'teen' ? 8 : 10);
  
  const sequence = Array.from({ length: count }, () => 
    symbols[Math.floor(Math.random() * symbols.length)]
  );
  
  const targetCount = sequence.filter(s => s === targetSymbol).length;
  const options = [
    targetCount.toString(),
    (targetCount + 1).toString(),
    Math.max(0, targetCount - 1).toString(),
    (targetCount + 2).toString(),
  ].sort(() => Math.random() - 0.5);

  return {
    id: Date.now(),
    type: 'focus',
    difficulty,
    ageGroup,
    question: `Quantas vezes o símbolo ${targetSymbol} aparece?\n${sequence.join(' ')}`,
    options,
    correctAnswer: targetCount.toString(),
    points: Math.floor(difficulty * 25 * config.pointsMultiplier),
    timeLimit: Math.floor((20 - Math.min(10, difficulty)) * config.timeMultiplier)
  };
};

const generateReactionChallenge = (difficulty: number, ageGroup: 'child' | 'teen' | 'adult'): Challenge => {
  const config = ageGroupConfigs[ageGroup];
  let num1: number, num2: number, operation: string, result: number;
  
  if (ageGroup === 'child') {
    operation = '+';
    num1 = Math.floor(Math.random() * (5 + difficulty)) + 1;
    num2 = Math.floor(Math.random() * (5 + difficulty)) + 1;
    result = num1 + num2;
  } else if (ageGroup === 'teen') {
    const operations = ['+', '-', '×'];
    operation = operations[Math.floor(Math.random() * operations.length)];
    num1 = Math.floor(Math.random() * (8 + difficulty)) + 1;
    num2 = Math.floor(Math.random() * (8 + difficulty)) + 1;
    
    switch (operation) {
      case '+': result = num1 + num2; break;
      case '-': result = num1 - num2; break;
      case '×': result = num1 * num2; break;
      default: result = num1 + num2;
    }
  } else {
    const operations = ['+', '-', '×', '÷'];
    operation = operations[Math.floor(Math.random() * operations.length)];
    
    if (operation === '÷') {
      result = Math.floor(Math.random() * (10 + difficulty)) + 1;
      num2 = Math.floor(Math.random() * 5) + 1;
      num1 = result * num2;
    } else {
      num1 = Math.floor(Math.random() * (12 + difficulty)) + 1;
      num2 = Math.floor(Math.random() * (12 + difficulty)) + 1;
      
      switch (operation) {
        case '+': result = num1 + num2; break;
        case '-': result = num1 - num2; break;
        case '×': result = num1 * num2; break;
        default: result = num1 + num2;
      }
    }
  }

  const options = [
    result.toString(),
    (result + 1).toString(),
    (result - 1).toString(),
    (result + 2).toString(),
  ].sort(() => Math.random() - 0.5);

  return {
    id: Date.now(),
    type: 'reaction',
    difficulty,
    ageGroup,
    question: `Resolva rápido!\n${num1} ${operation} ${num2} = ?`,
    options,
    correctAnswer: result.toString(),
    points: Math.floor(difficulty * 30 * config.pointsMultiplier),
    timeLimit: Math.floor((12 - Math.min(6, difficulty)) * config.timeMultiplier)
  };
};

export const generateChallenge = (difficulty: number, ageGroup: 'child' | 'teen' | 'adult'): Challenge => {
  const config = ageGroupConfigs[ageGroup];
  const adjustedDifficulty = Math.min(
    Math.max(difficulty, config.minDifficulty),
    config.maxDifficulty
  );
  
  const challengeTypes = [
    generateSequenceChallenge,
    generatePatternChallenge,
    generateMemoryChallenge,
    generateFocusChallenge,
    generateReactionChallenge
  ];
  
  const randomType = challengeTypes[Math.floor(Math.random() * challengeTypes.length)];
  return randomType(adjustedDifficulty, ageGroup);
};