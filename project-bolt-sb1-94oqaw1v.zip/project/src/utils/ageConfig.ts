import { AgeGroupConfig } from '../types';

export const getAgeGroup = (age: number): 'child' | 'teen' | 'adult' => {
  if (age < 13) return 'child';
  if (age < 18) return 'teen';
  return 'adult';
};

export const ageGroupConfigs: Record<'child' | 'teen' | 'adult', AgeGroupConfig> = {
  child: {
    minDifficulty: 1,
    maxDifficulty: 5,
    timeMultiplier: 1.3,
    pointsMultiplier: 1
  },
  teen: {
    minDifficulty: 2,
    maxDifficulty: 8,
    timeMultiplier: 1,
    pointsMultiplier: 1.2
  },
  adult: {
    minDifficulty: 3,
    maxDifficulty: 10,
    timeMultiplier: 0.8,
    pointsMultiplier: 1.5
  }
};