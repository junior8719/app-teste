import React, { useState } from 'react';
import GameBoard from './components/GameBoard';
import AgeSelector from './components/AgeSelector';
import { getAgeGroup } from './utils/ageConfig';

function App() {
  const [selectedAge, setSelectedAge] = useState<number | null>(null);

  if (!selectedAge) {
    return <AgeSelector onAgeSelect={setSelectedAge} />;
  }

  return <GameBoard ageGroup={getAgeGroup(selectedAge)} />;
}

export default App;