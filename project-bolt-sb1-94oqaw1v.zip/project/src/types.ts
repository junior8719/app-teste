export interface Challenge {
  id: number;
  type: 'sequence' | 'pattern' | 'memory' | 'focus' | 'reaction';
  difficulty: number;
  ageGroup: 'child' | 'teen' | 'adult';
  question: string;
  options: string[];
  correctAnswer: string;
  points: number;
  timeLimit?: number;
}

export interface GameState {
  score: number;
  level: number;
  currentStreak: number;
  bestStreak: number;
  lives: number;
  focusPoints: number;
  timeBonus: number;
  ageGroup: 'child' | 'teen' | 'adult';
}

export interface TimerState {
  timeLeft: number;
  isActive: boolean;
}

export interface AgeGroupConfig {
  minDifficulty: number;
  maxDifficulty: number;
  timeMultiplier: number;
  pointsMultiplier: number;
}